const mongoose = require('mongoose')
const express=require('express')
const app=express()
const mongoURI = "mongodb://127.0.0.1:27017/?readPreference=primaryPreferred&tls=false"

const connectToMongo = () => {
        mongoose.connect(mongoURI,{config:{ autoIndex: false }}, (err) =>{
                
                if(err)
                {
                        console.log(err);
               }
                 else{
                console.log("successfully connected to mongo")
               }
        }) 
        }
module.exports = connectToMongo;